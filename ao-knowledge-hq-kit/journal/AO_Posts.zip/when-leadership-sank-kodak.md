{\rtf1\ansi\ansicpg1252\cocoartf2822
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 ---\
title: "When Leadership Sank Kodak"\
slug: "when-leadership-sank-kodak"\
publish_date: "2025-08-26"\
created_at: "2025-08-26"\
updated_at: "2025-10-28"\
summary: "Kodak\'92s downfall wasn\'92t technological\'97it was a failure of leadership. A reflection on fear, control, and how servant leadership could have saved an empire built on memories."\
categories: ["case-studies", "power-control", "servant-leadership", "fear"]\
featured_image: "../images/when-leadership-sank-kodak.jpg"\
takeaways: []\
applications: []\
related: []\
original_source: "Facebook"\
original_url: "https://www.facebook.com/share/p/17GtMQni1T/"\
---\
\
# When Leadership Sank Kodak\
\
![When Leadership Sank Kodak](../images/when-leadership-sank-kodak.jpg)\
\
There was a time when Kodak wasn\'92t just a photography company\'97it was the photography company. Their film was in nearly every camera. Their brand was synonymous with memories. They even invented the digital camera in 1975, long before it became mainstream.\
\
And yet, by 2012, Kodak filed for bankruptcy.\
\
How does a company invent the very future of its own industry\'85 and then collapse because of it?\
\
The answer isn\'92t technology. The answer is leadership.\
\uc0\u11835 \
## The Psychology of Control\
\
Kodak\'92s executives understood the threat of digital photography, but they feared it more than they embraced it. Why? Because their profits were built on film. Every roll of film developed was another dollar in the bank. Digital cameras disrupted that steady stream.\
\
Instead of serving their people\'97the customers, the employees, and even the culture of photography itself\'97they tried to serve their profit model. Leadership clung to control, protecting what was instead of investing in what could be.\
\
Psychologists call this **status quo bias**: the tendency to prefer the familiar over the unknown, even when the unknown holds more promise. Leaders under fear grip tighter to what they know, and in doing so, they often strangle the very future of their organization.\
\uc0\u11835 \
## The Servant Leader\'92s Alternative\
\
Servant leadership flips this on its head. A servant leader doesn\'92t ask, *How do we protect what we\'92ve built?* but rather, *How do we continue to serve the people we exist for\'97even if it costs us?*\
\
Imagine if Kodak had approached the rise of digital photography not as a threat to their revenue but as a chance to help the world capture life more freely, more immediately, more joyfully. They had the technology. They had the trust. They had the people. What they lacked was the humility to sacrifice short-term security for long-term impact.\
\uc0\u11835 \
## Why It Matters for Us\
\
Leadership failure often comes disguised as \'93prudent caution\'94 or \'93protecting the bottom line.\'94 But the truth is, when leaders put control and profit above people and purpose, the end is already in motion. Kodak\'92s story isn\'92t just about cameras. It\'92s about what happens when leaders forget who they\'92re called to serve.\
\
Every leader will face their \'93Kodak moment\'94\'97that decision point where the future asks for courage while the past begs for comfort. Servant leaders choose courage. They choose people. And because of that, their legacy doesn\'92t collapse into bankruptcy\'97it multiplies into something that outlives them.\
\
#LeadershipPost  \
\
*Originally published on Facebook on August 26, 2025*\
}